# Text - String
name = "Elon"
SecondName = 'Musk'
Biography = """biografia completa do elon musk aqui"""

print(name)
print(SecondName)
print(Biography)

# Number - Int
age = 50 
km_rodado = 21862
qnt_laranjas = 3
qnt_filhos = 2

print(qnt_filhos)
print(age)

#Number - Float
qnt_laranjas_p_filho = qnt_laranjas/qnt_filhos
a = 1.5

print(qnt_laranjas_p_filho)

#Boolean - True or False
ligado = True
desligado = False

#Mat operation 
soma = 10 + 5
subtracao = 10 - 5
multiplicacao = 10 * 5
divisao = 11 / 2
potencia = 2 ** 3
modulo = 10 % 3 #resto da divisão
divsao_inteira = 10 // 3 

print(divisao)


#List 
frutas = ["laranja", "maçã", "banana", "tomate"]
#list - [0,1,2,3]

frutas.append("manga")
frutas.append("uva")
frutas.remove("maçã")

print(frutas)
print(frutas[2])
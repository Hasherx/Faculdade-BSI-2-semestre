#lista

carros=["fiat", "bentley", "bmw", "audi", "chevrolet"]

carros.append("Rolls Royce")
carros.remove("chevrolet")

print(carros)
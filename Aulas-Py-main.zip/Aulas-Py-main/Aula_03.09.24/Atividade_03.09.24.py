 # Crie uma variável que armazene o nome de uma pessoa. Em seguida, exiba essa variável.  

name = "brayan"

print(name)

#Crie duas variáveis que armazenem números inteiros. Some esses números e exiba o resultado.

number1 = 5
number2 = 5

print(number1 + number2)

#Crie uma lista que contenha os nomes de três frutas. Em seguida, exiba o segundo item da lista.
frutas = ["maçã", "banana", "laranja"]

print(frutas[1])

#Adicione um item à lista de frutas criada na questão anterior e exiba a lista atualizada.
frutas.append("morango")
print(frutas)

#Remova o primeiro item da lista de frutas e exiba a lista resultante.
frutas.remove("maçã")
print(frutas)

#Crie uma lista com cinco números inteiros. Em seguida, calcule e exiba a soma de todos os números da lista.
numbers = [1, 2, 3, 4, 5]
print(sum(numbers))




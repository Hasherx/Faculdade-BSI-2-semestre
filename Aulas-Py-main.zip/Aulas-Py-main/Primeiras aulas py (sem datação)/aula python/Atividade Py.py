# Exercício 1
nome = "brayan"
idade ="25"

print("Exercício 1:")
print(nome + " " + idade)
print()

# Exercício 2
a = 10
b = 5

soma = a + b

print("Exercício 2:")
print(soma)
print()

# Exercício 3
numero = 7
resultado = numero * 3

print("Exercício 3:")
print(resultado)
print()

# Exercício 4
valor1 = 20
valor2 = 4

resultado = valor1 - valor2

print("Exercício 4:")
print(resultado)
print()

# Exercício 5
numerador = 50
denominador = 2

resultado = numerador / denominador

print("Exercício 5:")
print(resultado)
print()

# Exercício 6
def simplefunc(nome):
    print(f"Olá, {nome}!")

print("Exercício 6:")
simplefunc("Brayan")
print()

# Exercício 7
def soma2(a, b):
    return a + b

resultado = soma2(10, 5)
print("Exercício 7:")
print(resultado)
print()

# Exercício 8
def multiplicacao(a, b):
    return a * b

resultado = multiplicacao(7, 3)
print("Exercício 8:")
print(resultado)
print()

# Exercício 9
nome = "Brayan"
sobrenome = "Rodrigues"

nome_completo = nome + " " + sobrenome

print("Exercício 9:")
print(nome_completo)
print()

# Exercício 10
def mensagem(nome):
    return f"Bom dia, {nome}!"

Salve = mensagem("Brayan")
print("Exercício 10:")
print(Salve)

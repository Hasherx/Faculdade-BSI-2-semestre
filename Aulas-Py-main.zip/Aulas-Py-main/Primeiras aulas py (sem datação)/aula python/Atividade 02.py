# **1. Tipos de dados em Python**
print("**1. Tipos de dados em Python**")
print("A) Bool – armazena um valor lógico: falso ou verdadeiro.")
print("B) Float – armazena números de ponto flutuante.")

# **2. Nomenclatura de variáveis em Python**
print("**2. Nomenclatura de variáveis em Python**")
print("D) _sobrenome = “Silva”.\n")

# **3. Escopo de variáveis em Python**
print("**3. Escopo de variáveis em Python**")
print("A) Dentro da função onde foi declarada; em todo o programa.\n")

# **4. Uso de variáveis globais em funções**
print("**4. Uso de variáveis globais em funções**")
print("D) Utilize a instrução global nome_aluno antes de atribuir um valor à variável, para forçar o uso da variável global na função.\n")

# **5. Exemplo de variável local e global com o mesmo nome**
print("**5. Exemplo de variável local e global com o mesmo nome**")
print("A) Imprime como resultado os números 1 e 0.")
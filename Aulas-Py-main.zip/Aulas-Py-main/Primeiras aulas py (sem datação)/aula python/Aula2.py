#Armazenar as variáveis n1 e n2 na memória

    #nome_da_ariavel = 'valor da variavel'

nome,idade = "brayan", "18"

r = nome +" " + idade

print(r)
#COMENT

    #BUILT IN
        #comando print
print("Hello World!")
    
        #criação e declaração de variaveis
HEY = "Seila cara" #string
print(HEY)

    #Adição de dados

Nome = "Brayan"

Sobrenome = "Rodrigues"

udade = "18" # Mesmo o Py reconhecendo o numero transformar para somar 


print("Name:"+ Nome)
print("Sobrenome:"+ Sobrenome)
print("Idade:"+ udade ) 

#imprimir dados no terminal
    #\n usado para pular linhas
nome=input("\nNome : ")
sobrenome=input("\nSobrenome : ")
Idade=int(input("\nIdade : "))
if Idade >= 18 :
    if Idade >50 :
        print("Sr.", sobrenome , "seja bem vindo")
    else :
        print("Seja bem vindo")
else:
    print("SAIA CRIANÇA")
        
print("espero que aproveite")

    #Tipos de dados
var01 = 122 #integer (inteiro)
var02 = 123.5 #float (decilmal)
var03 = "maria" #string
var04 = True #booleano ( Verdad ou falso)

    
